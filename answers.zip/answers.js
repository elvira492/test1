// 1
const array1 = [
    object1 = {
        idNummer: 1,
        email: "email@gmail.com",
        isVerified: true,
    },
    object2 = {
        idNummer: 2,
        email: "email@gmail.com",
        isVerified: false,
    },
    object3 = {
        idNummer: 3,
        email: "email@gmail.com",
        isVerified: true,
    },

];

// 2 
const array2 = [];
for (let i = 0; i <= 1000;i++) {
     i % 3 === 0 ? array2.push(0) : array2.push[i];
}
console.log(array2)

// 3



// 4
const array4 = [1, 2, 3, 4];
const newArray4 = [];

const answer = (number) => {
   for(let i = 0; i < array4.length; i++) {
   newArray4.push(array4[i]);
   array4 / (array4.length);
   }return newArray4;
}
console.log(answer(newArray4))

// 5
class Product {
    constructor(name, price){
        this.name = "iPhone";
        this.price = 200;
    }
}


//6